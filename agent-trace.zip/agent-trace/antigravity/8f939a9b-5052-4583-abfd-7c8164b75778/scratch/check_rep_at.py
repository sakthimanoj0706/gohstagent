import os
import csv

dataset_dir = r"D:\hacker\dataset"

all_reqs = []
for fn in ["sample_deletion_requests.csv", "deletion_requests.csv"]:
    with open(os.path.join(dataset_dir, fn), "r", encoding="utf-8") as f:
        all_reqs.extend(list(csv.DictReader(f)))

with open(os.path.join(dataset_dir, "user_identities.csv"), "r", encoding="utf-8") as f:
    users = list(csv.DictReader(f))
with open(os.path.join(dataset_dir, "user_audit_log.csv"), "r", encoding="utf-8") as f:
    audits = list(csv.DictReader(f))

email_to_user = {u["email"].lower(): u["user_id"] for u in users}
for a in audits:
    if a["field_name"] == "email":
        email_to_user[a["old_value"].lower()] = a["user_id"]
        email_to_user[a["new_value"].lower()] = a["user_id"]

print("=== Requests with reported_at around 2026-09-06 ===")
for r in all_reqs:
    if "2026-09-06" in r["reported_at"]:
        uid = email_to_user.get(r["email"].lower(), "?")
        print(f"{r['case_id']} | uid={uid} | email={r['email']} | req_at={r['requested_at']} | rep_at={r['reported_at']} | status={r['reported_status']}")

print("\n=== Requests with reported_at around 2026-09-02 ===")
for r in all_reqs:
    if "2026-09-02" in r["reported_at"]:
        uid = email_to_user.get(r["email"].lower(), "?")
        print(f"{r['case_id']} | uid={uid} | email={r['email']} | req_at={r['requested_at']} | rep_at={r['reported_at']} | status={r['reported_status']}")
