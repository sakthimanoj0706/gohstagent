import csv, json
from datetime import datetime

with open("dataset/sample_deletion_requests.csv", "r", encoding="utf-8") as f:
    sample_reqs = list(csv.DictReader(f))
with open("dataset/deletion_requests.csv", "r", encoding="utf-8") as f:
    eval_reqs = list(csv.DictReader(f))
all_reqs = sample_reqs + eval_reqs

with open("dataset/system_activity.csv", "r", encoding="utf-8") as f:
    acts = list(csv.DictReader(f))

def parse_t(s):
    return datetime.fromisoformat(s.replace("Z", "+00:00"))

# Let's check the formula for ev-rep of DELETE_RECORD -> account_service on case_11..case_32!
with open("dataset/sample_output.csv", "r", encoding="utf-8") as f:
    sample_out = {r["case_id"]: json.loads(r["steps_json"]) for r in csv.DictReader(f)}

by_res = {}
for a in acts:
    by_res.setdefault(a["resource_id"], []).append(a)

for idx in range(10, 32):
    r = sample_reqs[idx]
    cid = r["case_id"]
    cnum = int(cid.split("_")[1])
    unum = cnum if cnum <= 10 else cnum
    # wait: what is user_id for case_11..32?
    rep_t = parse_t(r["reported_at"])
    req_t = parse_t(r["requested_at"])
    for s in sample_out[cid]:
        rid = s["resource_id"]
        for a in by_res.get(rid, []):
            if a["event_type"] == "DELETE_RECORD" and a["target_system"] == "account_service":
                ev_t = parse_t(a["event_time"])
                print(f"{cid} (cnum={cnum:2d}): ev-rep = {(ev_t - rep_t).total_seconds():8.0f}s | ev_time={a['event_time']} | rep={r['reported_at']}")
                break
