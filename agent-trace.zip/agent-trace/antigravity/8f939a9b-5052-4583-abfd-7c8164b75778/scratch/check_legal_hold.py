import os, re, csv

for root, dirs, files in os.walk("dataset"):
    for fn in files:
        fp = os.path.join(root, fn)
        if fn.endswith((".csv", ".sql", ".json", ".log", ".txt")):
            with open(fp, "r", encoding="utf-8", errors="ignore") as f:
                for line in f:
                    if "legal_hold" in line or "legal_service" in line:
                        print(f"{fn}: {line.strip()[:120]}")
