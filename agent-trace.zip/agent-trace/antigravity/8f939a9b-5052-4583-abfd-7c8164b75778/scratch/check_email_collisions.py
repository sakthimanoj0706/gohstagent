import csv
from collections import defaultdict

with open("dataset/user_identities.csv", "r", encoding="utf-8") as f:
    identities = list(csv.DictReader(f))
with open("dataset/user_audit_log.csv", "r", encoding="utf-8") as f:
    audits = list(csv.DictReader(f))

email_to_users = defaultdict(set)
for r in identities:
    email_to_users[r["email"].lower()].add((r["user_id"], "current"))
for r in audits:
    if r["field_name"] == "email":
        email_to_users[r["old_value"].lower()].add((r["user_id"], "old"))
        email_to_users[r["new_value"].lower()].add((r["user_id"], "new"))

for em, us in sorted(email_to_users.items()):
    uids = set(u for u, _ in us)
    if len(uids) > 1:
        print(f"COLLISION on {em}: {us}")

with open("dataset/sample_deletion_requests.csv", "r", encoding="utf-8") as f:
    sreqs = list(csv.DictReader(f))
with open("dataset/deletion_requests.csv", "r", encoding="utf-8") as f:
    ereqs = list(csv.DictReader(f))

u_to_cases = defaultdict(list)
for r in sreqs + ereqs:
    uids = sorted(set(u for u, _ in email_to_users[r["email"].lower()]))
    if len(uids) != 1:
        print(f"Case {r['case_id']} email {r['email']} -> {uids}")
    else:
        u_to_cases[uids[0]].append(r["case_id"])

for u, cids in sorted(u_to_cases.items()):
    if len(cids) > 1:
        print(f"User {u} has multiple cases: {cids}")
