import csv
from collections import defaultdict

with open("dataset/user_identities.csv", "r", encoding="utf-8") as f:
    identities = list(csv.DictReader(f))
with open("dataset/user_audit_log.csv", "r", encoding="utf-8") as f:
    audits = list(csv.DictReader(f))

email_to_u = {}
for r in identities:
    email_to_u[r["email"].lower()] = r["user_id"]
for r in audits:
    if r["field_name"] == "email":
        email_to_u[r["old_value"].lower()] = r["user_id"]
        email_to_u[r["new_value"].lower()] = r["user_id"]

with open("dataset/sample_deletion_requests.csv", "r", encoding="utf-8") as f:
    sreqs = list(csv.DictReader(f))
with open("dataset/deletion_requests.csv", "r", encoding="utf-8") as f:
    ereqs = list(csv.DictReader(f))

all_reqs = sreqs + ereqs
u_to_cases = defaultdict(list)
for r in all_reqs:
    uid = email_to_u[r["email"].lower()]
    u_to_cases[uid].append(r["case_id"])

all_uids = [f"user_{i:02d}" if i < 100 else f"user_{i}" for i in range(1, 551)]
missing_uids = [u for u in all_uids if u not in u_to_cases]
multi_uids = {u: cids for u, cids in u_to_cases.items() if len(cids) > 1}
print("Missing user_ids (0 cases):", missing_uids)
print("Multi-case user_ids:", multi_uids)

for r in all_reqs:
    cnum = int(r["case_id"].split("_")[1])
    unum = int(email_to_u[r["email"].lower()].split("_")[1])
    if cnum != unum:
        print(f"Mismatch: {r['case_id']:8s} -> user_{unum:03d} | aud={r['audit_at']} | rep={r['reported_at']} | email={r['email']}")
