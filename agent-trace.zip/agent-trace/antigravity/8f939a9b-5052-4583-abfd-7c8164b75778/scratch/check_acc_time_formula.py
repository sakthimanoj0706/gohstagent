import csv
from datetime import datetime
from crack_audit_formula import clean_pairs

with open("dataset/user_identities.csv", "r", encoding="utf-8") as f:
    email_to_u = {r["email"].lower(): int(r["user_id"].split("_")[1]) for r in csv.DictReader(f)}
with open("dataset/user_audit_log.csv", "r", encoding="utf-8") as f:
    for r in csv.DictReader(f):
        if r["field_name"] == "email":
            email_to_u[r["old_value"].lower()] = int(r["user_id"].split("_")[1])
            email_to_u[r["new_value"].lower()] = int(r["user_id"].split("_")[1])

with open("dataset/sample_deletion_requests.csv", "r", encoding="utf-8") as f:
    sample_reqs = list(csv.DictReader(f))
with open("dataset/deletion_requests.csv", "r", encoding="utf-8") as f:
    eval_reqs = list(csv.DictReader(f))
all_reqs = sample_reqs + eval_reqs
u_to_req = {email_to_u[r["email"].lower()]: r for r in all_reqs}

with open("dataset/system_activity.csv", "r", encoding="utf-8") as f:
    acts = list(csv.DictReader(f))

by_res = {}
for a in acts:
    if a["event_type"] == "DELETE_RECORD" and a["target_system"] == "account_service":
        by_res[a["resource_id"]] = a

def parse_t(s):
    return datetime.fromisoformat(s.replace("Z", "+00:00"))

for u in sorted(clean_pairs.keys()):
    if u <= 10 or "account" not in clean_pairs[u]:
        continue
    acc_num = clean_pairs[u]["account"]
    rid = f"account_{acc_num:03d}" if acc_num < 1000 else f"account_{acc_num}"
    if rid not in by_res:
        continue
    r = u_to_req[u]
    cnum = int(r["case_id"].split("_")[1])
    a = by_res[rid]
    rep_t = parse_t(r["reported_at"])
    ev_t = parse_t(a["event_time"])
    diff = int((rep_t - ev_t).total_seconds())
    m = diff // 60
    s = diff % 60
    if u <= 70:
        print(f"u={u:3d} | c={cnum:3d} | diff={diff:5d}s | M={m:2d} (f={45+((11*u-1)%31):2d}) | S={s:2d} | ev_sec={ev_t.second:2d} | {rid:12s} | {a['activity_id']}")
