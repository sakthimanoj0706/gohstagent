from crack_audit_formula import clean_pairs

aud = {u: clean_pairs[u]["audit_record"] for u in clean_pairs if u > 10 and "audit_record" in clean_pairs[u]}

for u in sorted(aud):
    if (u-1) in aud and (u+1) in aud:
        d1 = aud[u] - aud[u-1]
        d2 = aud[u+1] - aud[u]
        dd = d2 - d1
        print(f"u={u:3d}: val={aud[u]:4d} | d1={d1:5d} | d2={d2:5d} | dd={dd:6d} | dd%9000={dd%9000:4d} | dd%9900={dd%9900:4d} | dd%9973={dd%9973:4d}")
