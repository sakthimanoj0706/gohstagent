import os
import csv
import re

dataset_dir = r"D:\hacker\dataset"
with open(os.path.join(dataset_dir, "user_identities.csv"), "r", encoding="utf-8") as f:
    email_to_u = {r["email"].lower(): int(r["user_id"].split("_")[1]) for r in csv.DictReader(f)}

with open(os.path.join(dataset_dir, "evidence", "logs", "cloud_runtime_export_af_south_20260930.log"), "r", encoding="utf-8") as f:
    for i, line in enumerate(f):
        if i > 20: break
        m_tr = re.search(r"requestId=(tr-\d+)", line)
        m_acc = re.search(r'resource_id=\\"account_(\d+)\\"', line)
        m_em = re.search(r'correlation_key=\\"([^\\"]+)\\"', line)
        if m_acc and m_em:
            u = email_to_u.get(m_em.group(1).lower())
            print(f"line={i:2d} u={u} tr={m_tr.group(1)} acc={m_acc.group(1)} em={m_em.group(1)}")
