import csv, sys
sys.stdout.reconfigure(encoding="utf-8")

with open("dataset/sample_deletion_requests.csv", "r", encoding="utf-8") as f:
    sreqs = list(csv.DictReader(f))
with open("dataset/deletion_requests.csv", "r", encoding="utf-8") as f:
    ereqs = list(csv.DictReader(f))

all_reqs = {r["case_id"]: r for r in sreqs + ereqs}
for cid in ["case_33", "case_34", "case_35", "case_39", "case_45", "case_46", "case_50", "case_52", "case_53", "case_55", "case_61", "case_63"]:
    r = all_reqs[cid]
    print(f"{cid} | {r['email']} | status={r['reported_status']} | aud={r['audit_at']} | text={r['request_text']}")
