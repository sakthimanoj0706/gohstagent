import os
import csv

dataset_dir = r"D:\hacker\dataset"
with open(os.path.join(dataset_dir, "sample_deletion_requests.csv"), "r", encoding="utf-8") as f:
    s_reqs = list(csv.DictReader(f))
with open(os.path.join(dataset_dir, "deletion_requests.csv"), "r", encoding="utf-8") as f:
    e_reqs = list(csv.DictReader(f))

all_reqs = {r["case_id"]: r for r in s_reqs + e_reqs}
# Cohort 41..50 cases:
# u=41->case_43, u=42->case_44, u=43->case_03, slot 44->case_46, u=45->case_47, u=46->case_48, u=47->case_49, u=48->case_20, u=49->case_51, u=50->case_18
cids = ["case_43", "case_44", "case_03", "case_46", "case_47", "case_48", "case_49", "case_20", "case_51", "case_18"]
for idx, cid in enumerate(cids, start=41):
    r = all_reqs[cid]
    print(f"slot={idx} {cid:8s}: email={r['email']:28s} req_at={r['requested_at']} rep_at={r['reported_at']} rep_status={r['reported_status']}")
