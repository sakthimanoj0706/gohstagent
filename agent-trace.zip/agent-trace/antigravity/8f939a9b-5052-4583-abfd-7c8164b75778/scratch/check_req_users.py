import os
import csv

dataset_dir = r"D:\hacker\dataset"

with open(os.path.join(dataset_dir, "user_identities.csv"), "r", encoding="utf-8") as f:
    users = {r["user_id"]: r for r in csv.DictReader(f)}
with open(os.path.join(dataset_dir, "user_audit_log.csv"), "r", encoding="utf-8") as f:
    audits = list(csv.DictReader(f))

email_to_uid = {u["email"].lower(): uid for uid, u in users.items()}
for a in audits:
    if a["field_name"] == "email":
        email_to_uid[a["old_value"].lower()] = a["user_id"]
        email_to_uid[a["new_value"].lower()] = a["user_id"]

with open(os.path.join(dataset_dir, "sample_deletion_requests.csv"), "r", encoding="utf-8") as f:
    s_reqs = list(csv.DictReader(f))
with open(os.path.join(dataset_dir, "deletion_requests.csv"), "r", encoding="utf-8") as f:
    e_reqs = list(csv.DictReader(f))

print("Sample requests (32):")
for r in s_reqs:
    uid = email_to_uid.get(r["email"].lower())
    print(f"  {r['case_id']:8s} -> {str(uid):8s} ({r['email']}) audit_at={r['audit_at']}")

print("\nFirst 40 eval requests:")
for r in e_reqs[:40]:
    uid = email_to_uid.get(r["email"].lower())
    print(f"  {r['case_id']:8s} -> {str(uid):8s} ({r['email']}) audit_at={r['audit_at']}")
