import csv
from check_fixed_missing_aud import clean_pairs

res_to_u = {}
for u, d in clean_pairs.items():
    for pref, num in d.items():
        rid = f"{pref}_{num:03d}" if num < 1000 and u <= 10 else f"{pref}_{num}"
        res_to_u[rid] = u
        if num < 1000:
            res_to_u[f"{pref}_{num:03d}"] = u

with open("dataset/system_activity.csv", "r", encoding="utf-8") as f:
    acts = list(csv.DictReader(f))

for a in acts:
    if a["source_system"] == "deletion_worker" and ":31:" in a["event_time"]:
        ss = int(a["event_time"].split(":")[-1].replace("Z", ""))
        u = res_to_u.get(a["resource_id"])
        print(f"{a['activity_id']:12s} | {a['event_time']} | SS={ss:2d} | {a['target_system']:18s} | {a['resource_id']:18s} | u={u}")
