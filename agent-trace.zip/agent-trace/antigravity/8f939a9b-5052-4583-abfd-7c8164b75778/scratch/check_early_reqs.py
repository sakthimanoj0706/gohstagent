import os
import csv

dataset_dir = r"D:\hacker\dataset"

all_reqs = []
for fn in ["sample_deletion_requests.csv", "deletion_requests.csv"]:
    with open(os.path.join(dataset_dir, fn), "r", encoding="utf-8") as f:
        all_reqs.extend(list(csv.DictReader(f)))

for r in sorted(all_reqs, key=lambda x: x["reported_at"])[:20]:
    print(f"{r['case_id']:8s} | req={r['requested_at']} | rep={r['reported_at']} | aud={r['audit_at']} | {r['reported_status']:18s} | {r['email']}")
