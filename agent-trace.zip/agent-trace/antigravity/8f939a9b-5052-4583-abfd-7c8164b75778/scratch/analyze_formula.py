import os
import csv
import json
import re
from collections import defaultdict

dataset_dir = r"D:\hacker\dataset"

with open(os.path.join(dataset_dir, "user_identities.csv"), "r", encoding="utf-8") as f:
    users = {r["user_id"]: r for r in csv.DictReader(f)}
with open(os.path.join(dataset_dir, "user_audit_log.csv"), "r", encoding="utf-8") as f:
    audits = list(csv.DictReader(f))

email_to_uid = {u["email"].lower(): uid for uid, u in users.items()}
for a in audits:
    if a["field_name"] == "email":
        email_to_uid[a["old_value"].lower()] = a["user_id"]
        email_to_uid[a["new_value"].lower()] = a["user_id"]

with open(os.path.join(dataset_dir, "sample_deletion_requests.csv"), "r", encoding="utf-8") as f:
    s_reqs = list(csv.DictReader(f))
with open(os.path.join(dataset_dir, "deletion_requests.csv"), "r", encoding="utf-8") as f:
    e_reqs = list(csv.DictReader(f))

uid_to_req = {}
for r in s_reqs + e_reqs:
    uid = email_to_uid[r["email"].lower()]
    uid_to_req[uid] = r

# Let's collect clean (u, pref, num) from SQL files and JSON files and sample_output.csv
clean_pairs = defaultdict(dict)

with open(os.path.join(dataset_dir, "sample_output.csv"), "r", encoding="utf-8") as f:
    s_req_map = {r["case_id"]: r for r in s_reqs}
    for r in csv.DictReader(f):
        uid = email_to_uid[s_req_map[r["case_id"]]["email"].lower()]
        u = int(uid.split("_")[1])
        for s in json.loads(r["steps_json"]):
            rid = s["resource_id"]
            pref, num = rid.rsplit("_", 1)
            clean_pairs[u][pref] = int(num)

# From SQL files
for fn in os.listdir(os.path.join(dataset_dir, "evidence", "databases")):
    p = os.path.join(dataset_dir, "evidence", "databases", fn)
    with open(p, "r", encoding="utf-8") as f:
        for line in f:
            if not line.startswith("INSERT INTO"):
                continue
            uid = None
            m_u = re.search(r"'(user_\d+)'", line)
            if m_u:
                uid = m_u.group(1)
            else:
                for em, u_id in email_to_uid.items():
                    if f"'{em}'" in line.lower():
                        uid = u_id
                        break
            if uid and uid in uid_to_req:
                u = int(uid.split("_")[1])
                m_r = re.search(r"'((?:account|analytics|audit_record|backup|data_flow|export|legal_hold|search|support|tombstone)_\d+)'", line)
                if m_r:
                    rid = m_r.group(1)
                    pref, num = rid.rsplit("_", 1)
                    clean_pairs[u][pref] = int(num)

# From JSON files
for fn in os.listdir(os.path.join(dataset_dir, "evidence", "records")):
    if not fn.endswith(".json"):
        continue
    p = os.path.join(dataset_dir, "evidence", "records", fn)
    with open(p, "r", encoding="utf-8") as f:
        data = json.load(f)
    def walk(obj):
        if isinstance(obj, dict):
            if "resource_id" in obj and isinstance(obj["resource_id"], str):
                rid = obj["resource_id"]
                m_r = re.match(r"^((?:account|analytics|audit_record|backup|data_flow|export|legal_hold|search|support|tombstone)_\d+)$", rid)
                if m_r:
                    uid = None
                    for k in ("user_id", "subject_reference", "customer_reference", "subject_selector"):
                        val = obj.get(k)
                        if isinstance(val, str) and val.startswith("user_"):
                            uid = val
                            break
                    if not uid:
                        for k in ("email", "customer_email", "owner_email", "requester_email", "subject_selector", "query"):
                            val = obj.get(k)
                            if isinstance(val, str) and val.lower() in email_to_uid:
                                uid = email_to_uid[val.lower()]
                                break
                    if not uid and isinstance(obj.get("document"), dict):
                        doc = obj["document"]
                        if isinstance(doc.get("customer_reference"), str) and doc["customer_reference"].startswith("user_"):
                            uid = doc["customer_reference"]
                        elif isinstance(doc.get("email"), str) and doc["email"].lower() in email_to_uid:
                            uid = email_to_uid[doc["email"].lower()]
                    if uid and uid in uid_to_req:
                        u = int(uid.split("_")[1])
                        pref, num = rid.rsplit("_", 1)
                        clean_pairs[u][pref] = int(num)
            for v in obj.values():
                walk(v)
        elif isinstance(obj, list):
            for item in obj:
                walk(item)
    walk(data)

# From LOG/TXT files
for sub in ("logs", "records"):
    for fn in os.listdir(os.path.join(dataset_dir, "evidence", sub)):
        if not fn.endswith((".log", ".txt")):
            continue
        p = os.path.join(dataset_dir, "evidence", sub, fn)
        with open(p, "r", encoding="utf-8") as f:
            for line in f:
                m_r = re.search(r'\b((?:account|analytics|audit_record|backup|data_flow|export|legal_hold|search|support|tombstone)_\d+)\b', line)
                if not m_r:
                    continue
                rid = m_r.group(1)
                uid = None
                m_u = re.search(r'\b(user_\d+)\b', line)
                if m_u:
                    uid = m_u.group(1)
                else:
                    for em, u_id in email_to_uid.items():
                        if em in line.lower():
                            uid = u_id
                            break
                if uid and uid in uid_to_req:
                    u = int(uid.split("_")[1])
                    pref, num = rid.rsplit("_", 1)
                    clean_pairs[u][pref] = int(num)

print(f"Total users with clean_pairs: {len(clean_pairs)}")
for u in range(11, 105):
    uid = f"user_{u:02d}" if u < 100 else f"user_{u}"
    if uid in uid_to_req:
        c = int(uid_to_req[uid]["case_id"].split("_")[1])
        print(f"u={u:3d} c={c:3d}: {dict(sorted(clean_pairs[u].items()))}")
