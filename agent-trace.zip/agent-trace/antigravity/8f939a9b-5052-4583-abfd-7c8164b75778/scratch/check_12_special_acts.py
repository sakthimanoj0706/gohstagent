import csv

with open("dataset/deletion_requests.csv", "r", encoding="utf-8") as f:
    ereqs = {r["case_id"]: r for r in csv.DictReader(f)}
with open("dataset/system_activity.csv", "r", encoding="utf-8") as f:
    acts = list(csv.DictReader(f))

special = ["case_33", "case_34", "case_35", "case_39", "case_45", "case_46", "case_50", "case_52", "case_53", "case_55", "case_61", "case_63"]
for cid in special:
    r = ereqs[cid]
    print(f"=== {cid} | email={r['email']} | status={r['reported_status']} | req={r['requested_at']} | rep={r['reported_at']} | aud={r['audit_at']} ===")
    for a in acts:
        if r["requested_at"] <= a["event_time"] <= r["audit_at"] and a["source_system"] in ("deletion_worker", "data_catalog", "account_service", "backup_service"):
            print(f"   {a['activity_id']:12s} | {a['event_time']} | {a['source_system']:16s}->{a['target_system']:18s} | {a['event_type']:22s} | {a['resource_id']:16s} | {a['reported_result']}")
