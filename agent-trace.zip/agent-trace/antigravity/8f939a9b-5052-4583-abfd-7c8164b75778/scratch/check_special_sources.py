import csv

with open("dataset/system_activity.csv", "r", encoding="utf-8") as f:
    acts = list(csv.DictReader(f))

for a in acts:
    if a["source_system"] in ("privacy_intake", "backup_service", "data_catalog", "integration_service"):
        print(f"{a['activity_id']:12s} | {a['event_time']} | {a['source_system']:20s}->{a['target_system']:20s} | {a['event_type']:22s} | {a['resource_id']:18s} | {a['reported_result']:8s} | {a['details']}")
