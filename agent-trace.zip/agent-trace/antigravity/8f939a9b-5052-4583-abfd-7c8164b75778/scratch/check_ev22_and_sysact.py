import os
import csv
import json
import re

dataset_dir = r"D:\hacker\dataset"

with open(os.path.join(dataset_dir, "evidence", "records", "customer_data_snapshot_bundle_20260630.json"), "r", encoding="utf-8") as f:
    for i, line in enumerate(f, 1):
        if "audit_record_" in line:
            print(f"ev22 line {i}: {line.strip()}")

with open(os.path.join(dataset_dir, "system_activity.csv"), "r", encoding="utf-8") as f:
    aud_rows = [r for r in csv.DictReader(f) if "audit_record_" in r["resource_id"]]

print(f"\nsystem_activity.csv rows with audit_record_: {len(aud_rows)}")
for r in aud_rows[:25]:
    print(" ", r)
