import csv, json

with open("dataset/sample_deletion_requests.csv", "r", encoding="utf-8") as f:
    sample_reqs = list(csv.DictReader(f))
with open("dataset/sample_output.csv", "r", encoding="utf-8") as f:
    sample_out = {r["case_id"]: json.loads(r["steps_json"]) for r in csv.DictReader(f)}
with open("dataset/system_activity.csv", "r", encoding="utf-8") as f:
    acts = list(csv.DictReader(f))

by_res = {}
for a in acts:
    by_res.setdefault(a["resource_id"], []).append(a)

for r in sample_reqs:
    cid = r["case_id"]
    steps = sample_out[cid]
    res_ids = sorted(set(s["resource_id"] for s in steps))
    print(f"=== {cid} | req={r['requested_at']} | rep={r['reported_at']} | aud={r['audit_at']} ===")
    for rid in res_ids:
        for a in by_res.get(rid, []):
            print(f"   {rid:18s} | {a['activity_id']:12s} | {a['event_time']} | {a['source_system']}->{a['target_system']} | {a['event_type']}")
