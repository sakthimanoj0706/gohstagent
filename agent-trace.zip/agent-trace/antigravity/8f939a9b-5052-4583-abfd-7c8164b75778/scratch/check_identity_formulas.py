import os
import csv
import re

dataset_dir = r"D:\hacker\dataset"
with open(os.path.join(dataset_dir, "user_identities.csv"), "r", encoding="utf-8") as f:
    users = list(csv.DictReader(f))

for r in users[10:45]:
    u = int(r["user_id"].split("_")[1])
    em_digits = re.findall(r"\d+", r["email"])
    ph_digits = "".join(re.findall(r"\d+", r["phone"]))[-4:]
    print(f"u={u:2d} | {r['name']:20s} | {r['email']:30s} | em_num={str(em_digits):10s} | ph_last4={ph_digits}")
