import os

dataset_dir = r"D:\hacker\dataset"
for sub in ("logs", "records"):
    for fn in sorted(os.listdir(os.path.join(dataset_dir, "evidence", sub))):
        if fn.endswith((".log", ".txt")):
            p = os.path.join(dataset_dir, "evidence", sub, fn)
            with open(p, "r", encoding="utf-8") as f:
                lines = [f.readline().strip() for _ in range(5)]
            print(f"\n=== {fn} ===")
            for l in lines:
                if l:
                    print("  ", l[:140])
