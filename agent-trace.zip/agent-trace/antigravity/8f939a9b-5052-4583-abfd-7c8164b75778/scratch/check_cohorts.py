import os
import csv
import json
from collections import defaultdict

dataset_dir = r"D:\hacker\dataset"

with open(os.path.join(dataset_dir, "user_identities.csv"), "r", encoding="utf-8") as f:
    users = {r["user_id"]: r for r in csv.DictReader(f)}
with open(os.path.join(dataset_dir, "user_audit_log.csv"), "r", encoding="utf-8") as f:
    audits = list(csv.DictReader(f))

email_to_uid = {u["email"].lower(): uid for uid, u in users.items()}
for a in audits:
    if a["field_name"] == "email":
        email_to_uid[a["old_value"].lower()] = a["user_id"]
        email_to_uid[a["new_value"].lower()] = a["user_id"]

all_reqs = []
for fn in ["sample_deletion_requests.csv", "deletion_requests.csv"]:
    with open(os.path.join(dataset_dir, fn), "r", encoding="utf-8") as f:
        all_reqs.extend(list(csv.DictReader(f)))

uid_to_req = {}
for r in all_reqs:
    uid = email_to_uid.get(r["email"].lower())
    if uid:
        uid_to_req[uid] = r

for cohort_start in range(1, 551, 10):
    uids = [f"user_{u}" for u in range(cohort_start, cohort_start + 10)]
    auds = sorted(set(uid_to_req[u]["audit_at"] for u in uids if u in uid_to_req))
    cids = [uid_to_req[u]["case_id"] for u in uids if u in uid_to_req]
    print(f"Users {cohort_start:3d}..{cohort_start+9:3d} | cases={cids[0]}..{cids[-1]} | audit_at={auds}")
