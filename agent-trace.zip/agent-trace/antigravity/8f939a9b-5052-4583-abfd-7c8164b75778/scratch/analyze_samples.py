import os
import csv
import json
import hashlib

dataset_dir = r"D:\hacker\dataset"

with open(os.path.join(dataset_dir, "sample_deletion_requests.csv"), "r", encoding="utf-8") as f:
    reqs = {r["case_id"]: r for r in csv.DictReader(f)}

with open(os.path.join(dataset_dir, "sample_output.csv"), "r", encoding="utf-8") as f:
    outs = {r["case_id"]: r for r in csv.DictReader(f)}

with open(os.path.join(dataset_dir, "user_identities.csv"), "r", encoding="utf-8") as f:
    users = list(csv.DictReader(f))

with open(os.path.join(dataset_dir, "user_audit_log.csv"), "r", encoding="utf-8") as f:
    audits = list(csv.DictReader(f))

# Map email to user_id
email_to_user = {}
for u in users:
    email_to_user[u["email"].lower()] = u["user_id"]
for a in audits:
    if a["field_name"] == "email":
        email_to_user[a["old_value"].lower()] = a["user_id"]
        email_to_user[a["new_value"].lower()] = a["user_id"]

for cid in sorted(reqs.keys(), key=lambda x: int(x.split("_")[1])):
    req = reqs[cid]
    out = outs[cid]
    uid = email_to_user.get(req["email"].lower(), "UNKNOWN")
    steps = json.loads(out["steps_json"])
    rids = [(s["system_id"], s["resource_id"], s["operation"], s["evidence_id"]) for s in steps]
    print(f"{cid} | uid={uid} | email={req['email']} | req_at={req['requested_at']} | rep_at={req['reported_at']} | audit_at={req['audit_at']} | status={out['deletion_status']}")
    for sys_id, rid, op, evid in rids:
        print(f"   -> {sys_id} : {rid} ({op}) [ev={evid}]")
