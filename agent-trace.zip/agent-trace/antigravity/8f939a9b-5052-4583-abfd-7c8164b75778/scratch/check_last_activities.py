import csv

with open("dataset/system_activity.csv", "r", encoding="utf-8") as f:
    acts = list(csv.DictReader(f))

for a in acts[-35:]:
    print(f"{a['activity_id']:12s} | {a['event_time']} | {a['source_system']:18s}->{a['target_system']:18s} | {a['event_type']:22s} | {a['resource_id']:18s} | {a['reported_result']:8s} | {a['details']}")
