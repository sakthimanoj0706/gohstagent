import csv
from datetime import datetime

with open("dataset/user_identities.csv", "r", encoding="utf-8") as f:
    identities = list(csv.DictReader(f))
with open("dataset/user_audit_log.csv", "r", encoding="utf-8") as f:
    audits = list(csv.DictReader(f))

email_to_u = {r["email"].lower(): int(r["user_id"].split("_")[1]) for r in identities}
for r in audits:
    if r["field_name"] == "email":
        email_to_u[r["old_value"].lower()] = int(r["user_id"].split("_")[1])
        email_to_u[r["new_value"].lower()] = int(r["user_id"].split("_")[1])

with open("dataset/sample_deletion_requests.csv", "r", encoding="utf-8") as f:
    sreqs = list(csv.DictReader(f))
with open("dataset/deletion_requests.csv", "r", encoding="utf-8") as f:
    ereqs = list(csv.DictReader(f))

def parse_t(s):
    return datetime.fromisoformat(s.replace("Z", "+00:00"))

special_cids = {"case_33", "case_34", "case_35", "case_39", "case_45", "case_46", "case_50", "case_52", "case_53", "case_55", "case_61", "case_63"}
u_to_rep = {}
for r in sreqs + ereqs:
    if r["case_id"] in special_cids: continue
    u_to_rep[email_to_u[r["email"].lower()]] = (r["case_id"], parse_t(r["reported_at"]))

with open("dataset/system_activity.csv", "r", encoding="utf-8") as f:
    acts = list(csv.DictReader(f))

for a in acts:
    if a["target_system"] in ("legal_service", "identity_service") and a["source_system"] == "deletion_worker":
        ev_t = parse_t(a["event_time"])
        # find closest rep_t
        best = []
        for u, (cid, rep_t) in u_to_rep.items():
            diff = int((ev_t - rep_t).total_seconds())
            if abs(diff) <= 7200:
                best.append((diff, u, cid))
        print(f"{a['activity_id']:12s} | {a['event_time']} | {a['target_system']:18s} | {a['resource_id']:18s} | matches={best}")
