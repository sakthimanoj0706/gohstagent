import os
import csv
import json

dataset_dir = r"D:\hacker\dataset"

with open(os.path.join(dataset_dir, "user_identities.csv"), "r", encoding="utf-8") as f:
    users = {r["user_id"]: r for r in csv.DictReader(f)}
with open(os.path.join(dataset_dir, "user_audit_log.csv"), "r", encoding="utf-8") as f:
    audits = list(csv.DictReader(f))

email_to_uid = {u["email"].lower(): uid for uid, u in users.items()}
for a in audits:
    if a["field_name"] == "email":
        email_to_uid[a["old_value"].lower()] = a["user_id"]
        email_to_uid[a["new_value"].lower()] = a["user_id"]

all_reqs = []
for fn in ["sample_deletion_requests.csv", "deletion_requests.csv"]:
    with open(os.path.join(dataset_dir, fn), "r", encoding="utf-8") as f:
        all_reqs.extend(list(csv.DictReader(f)))

print("=== Cases with audit_at = 2026-09-26T11:00:00Z ===")
for r in all_reqs:
    if r["audit_at"] == "2026-09-26T11:00:00Z":
        uid = email_to_uid.get(r["email"].lower(), "?")
        print(f"{r['case_id']:8s} | uid={uid:8s} | req={r['requested_at']} | rep={r['reported_at']} | {r['reported_status']:18s} | {r['email']}")
