import os
import csv

dataset_dir = r"D:\hacker\dataset"

with open(os.path.join(dataset_dir, "user_identities.csv"), "r", encoding="utf-8") as f:
    users = {r["user_id"]: r for r in csv.DictReader(f)}
with open(os.path.join(dataset_dir, "user_audit_log.csv"), "r", encoding="utf-8") as f:
    audits = list(csv.DictReader(f))

email_to_uid = {u["email"].lower(): uid for uid, u in users.items()}
for a in audits:
    if a["field_name"] == "email":
        email_to_uid[a["old_value"].lower()] = a["user_id"]
        email_to_uid[a["new_value"].lower()] = a["user_id"]

with open(os.path.join(dataset_dir, "sample_deletion_requests.csv"), "r", encoding="utf-8") as f:
    s_reqs = list(csv.DictReader(f))
with open(os.path.join(dataset_dir, "deletion_requests.csv"), "r", encoding="utf-8") as f:
    e_reqs = list(csv.DictReader(f))

all_reqs = sorted(s_reqs + e_reqs, key=lambda r: int(r["case_id"].split("_")[1]))

for r in all_reqs:
    c = int(r["case_id"].split("_")[1])
    uid = email_to_uid.get(r["email"].lower())
    u = int(uid.split("_")[1]) if uid else -1
    if c <= 75 or abs(c - u) != 2:
        print(f"c={c:3d} ({r['case_id']:8s}) -> u={u:3d} ({uid:8s}) diff={c-u:3d} audit_at={r['audit_at']}")
