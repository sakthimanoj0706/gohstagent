import os
import csv
import json

dataset_dir = r"D:\hacker\dataset"

with open(os.path.join(dataset_dir, "sample_deletion_requests.csv"), "r", encoding="utf-8") as f:
    s_reqs = list(csv.DictReader(f))
with open(os.path.join(dataset_dir, "deletion_requests.csv"), "r", encoding="utf-8") as f:
    d_reqs = list(csv.DictReader(f))
all_reqs = s_reqs + d_reqs

with open(os.path.join(dataset_dir, "system_activity.csv"), "r", encoding="utf-8") as f:
    acts = list(csv.DictReader(f))

# Wait: let's look at ALL activities performed by source_system == 'deletion_worker' or 'privacy_intake'!
dw_acts = [a for a in acts if a["source_system"] in ("deletion_worker", "privacy_intake")]
print(f"Total deletion_worker / privacy_intake activities: {len(dw_acts)}")
for a in dw_acts[:40]:
    print(f"{a['activity_id']:13s} | {a['event_time']} | {a['event_type']:20s} | {a['target_system']:23s} | {a['resource_id']:18s} | {a['reported_result']:8s} | {a['details']}")
