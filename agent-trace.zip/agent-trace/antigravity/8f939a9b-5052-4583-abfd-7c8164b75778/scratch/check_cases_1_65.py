import csv
from collections import defaultdict

with open("dataset/user_identities.csv", "r", encoding="utf-8") as f:
    identities = list(csv.DictReader(f))
with open("dataset/user_audit_log.csv", "r", encoding="utf-8") as f:
    audits = list(csv.DictReader(f))

email_to_u = {}
for r in identities:
    email_to_u[r["email"].lower()] = r["user_id"]
for r in audits:
    if r["field_name"] == "email":
        email_to_u[r["old_value"].lower()] = r["user_id"]
        email_to_u[r["new_value"].lower()] = r["user_id"]

with open("dataset/sample_deletion_requests.csv", "r", encoding="utf-8") as f:
    sreqs = list(csv.DictReader(f))
with open("dataset/deletion_requests.csv", "r", encoding="utf-8") as f:
    ereqs = list(csv.DictReader(f))

all_reqs = sreqs + ereqs
for r in all_reqs[:65]:
    uid = email_to_u[r["email"].lower()]
    print(f"{r['case_id']:8s} -> {uid:8s} | email={r['email']:35s} | req={r['requested_at']} | rep={r['reported_at']} | aud={r['audit_at']}")
