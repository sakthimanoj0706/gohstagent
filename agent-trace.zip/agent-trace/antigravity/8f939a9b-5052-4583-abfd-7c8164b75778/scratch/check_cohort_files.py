import os
import csv
import json
import re
from collections import defaultdict

dataset_dir = r"D:\hacker\dataset"

with open(os.path.join(dataset_dir, "user_identities.csv"), "r", encoding="utf-8") as f:
    users = {r["user_id"]: r for r in csv.DictReader(f)}
with open(os.path.join(dataset_dir, "user_audit_log.csv"), "r", encoding="utf-8") as f:
    audits = list(csv.DictReader(f))

id_to_uid = {}
for uid, u in users.items():
    id_to_uid[uid] = uid
    id_to_uid[u["email"].lower()] = uid
    id_to_uid[u["phone"]] = uid
    id_to_uid[u["email_hash"]] = uid
for a in audits:
    uid = a["user_id"]
    if a["field_name"] == "email":
        id_to_uid[a["old_value"].lower()] = uid
        id_to_uid[a["new_value"].lower()] = uid
    elif a["field_name"] in ("phone", "email_hash"):
        id_to_uid[a["old_value"]] = uid
        id_to_uid[a["new_value"]] = uid

# Let's see which cohorts do NOT have customer_data_snapshot_bundle or SQL inventory!
# Wait: earlier we saw map_ev_users.py! Let's check for each cohort 1..550 which files exist!
with open(os.path.join(dataset_dir, "evidence_files.csv"), "r", encoding="utf-8") as f:
    evs = list(csv.DictReader(f))

cohort_files = defaultdict(list)
for ev in evs:
    fid = ev["file_id"]
    p = os.path.join(dataset_dir, ev["file_path"])
    found_u = set()
    if p.endswith((".json", ".sql", ".log", ".txt")):
        with open(p, "r", encoding="utf-8", errors="ignore") as fp:
            text = fp.read()
        for m in re.finditer(r"user_(\d+)\b", text):
            found_u.add(int(m.group(1)))
        for k, uid in id_to_uid.items():
            if "@" in k and k in text.lower():
                found_u.add(int(uid.split("_")[1]))
    for u in found_u:
        if 1 <= u <= 550:
            c_start = ((u - 1) // 10) * 10 + 1
            cohort_files[c_start].append((fid, os.path.basename(p)))

for c_start in range(1, 551, 10):
    files = sorted(set(cohort_files[c_start]))
    f_str = ", ".join(f"{fid}:{fn}" for fid, fn in files)
    print(f"Cohort {c_start:3d}..{c_start+9:3d}: {f_str}")
