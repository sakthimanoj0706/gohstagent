import json

with open(r"D:\hacker\dataset\evidence\records\customer_data_snapshot_bundle_20260630.json", "r", encoding="utf-8") as f:
    data = json.load(f)

for snap in data["snapshots"]:
    if snap["data_store"] == "security_service":
        print(f"captured_at={snap['captured_at']} count={len(snap['records'])}")
        for r in snap["records"]:
            print(" ", r)
