from crack_audit_formula import clean_pairs, users, uid_to_reqs

aud = {u: clean_pairs[u]["audit_record"] for u in clean_pairs if u > 10 and "audit_record" in clean_pairs[u]}

diffs = []
for u in sorted(aud):
    if (u - 1) in aud:
        diffs.append((aud[u] - aud[u-1], u))

diffs.sort()
print("Sorted first differences d = aud[u] - aud[u-1]:")
for i, (d, u) in enumerate(diffs):
    if i > 0 and abs(d - diffs[i-1][0]) <= 30:
        u_prev = diffs[i-1][1]
        d_prev = diffs[i-1][0]
        print(f"  d={d_prev:5d} (u={u_prev:3d}) vs d={d:5d} (u={u:3d}) | dd={d-d_prev:3d} | du={u-u_prev:3d}")
