import os, json, re

rec_dir = "dataset/evidence/records"
for fn in sorted(os.listdir(rec_dir)):
    if not fn.startswith("customer_data_snapshot_bundle"): continue
    with open(os.path.join(rec_dir, fn), "r", encoding="utf-8") as f:
        txt = f.read()
    users = sorted(set(int(x.split("_")[1]) for x in re.findall(r"user_\d+", txt)))
    auds = sorted(set(re.findall(r"audit_record_\d+", txt)))
    accs = sorted(set(re.findall(r"account_\d+", txt)))
    print(f"{fn:45s}: users={users[0] if users else None}..{users[-1] if users else None} (n={len(users)}), auds={len(auds)}, accs={len(accs)}")
