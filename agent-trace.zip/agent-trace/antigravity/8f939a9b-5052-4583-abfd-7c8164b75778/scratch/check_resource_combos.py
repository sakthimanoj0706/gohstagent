from check_fixed_missing_aud import clean_pairs

combos = set()
for u, d in sorted(clean_pairs.items()):
    combos.add(tuple(sorted(d.keys())))

for c in sorted(combos):
    print("Combo:", c)
