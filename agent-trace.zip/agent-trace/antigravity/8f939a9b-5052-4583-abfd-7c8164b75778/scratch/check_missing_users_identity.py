import csv

with open("dataset/user_identities.csv", "r", encoding="utf-8") as f:
    identities = list(csv.DictReader(f))
with open("dataset/user_audit_log.csv", "r", encoding="utf-8") as f:
    audits = list(csv.DictReader(f))

for u in ["user_07", "user_17", "user_18", "user_31", "user_44", "user_59"]:
    print("=== Identity for", u)
    for r in identities:
        if r["user_id"] == u:
            print("  CUR:", r)
    for r in audits:
        if r["user_id"] == u:
            print("  AUD:", r)
