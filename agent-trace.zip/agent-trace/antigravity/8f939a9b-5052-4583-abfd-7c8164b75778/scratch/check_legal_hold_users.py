from check_fixed_missing_aud import clean_pairs
import csv

with open("dataset/user_identities.csv", "r", encoding="utf-8") as f:
    u_to_em = {int(r["user_id"].split("_")[1]): r["email"].lower() for r in csv.DictReader(f)}

for u in [96, 97, 98, 218, 259, 285, 286, 287, 388, 430, 458, 471, 503, 509]:
    print(f"u={u:3d} (pos={(u-1)%10}): {clean_pairs.get(u)}")
