import re, json

with open("dataset/evidence/logs/service_events_ap_south_20260915.log", "r", encoding="utf-8") as f:
    lines = f.readlines()

traces = {}
for line in lines:
    m = re.search(r"trace_id=(tr-\d+)", line)
    if m:
        traces.setdefault(m.group(1), []).append(line.strip())

for tid, tlines in traces.items():
    joined = " ".join(tlines)
    for u in [11, 13, 14, 16, 17, 18, 20, 22]:
        if f"user_{u}" in joined:
            print(f"=== user_{u} in {tid} ===")
            for l in tlines:
                print("  ", l)
