import csv

with open("dataset/sample_deletion_requests.csv", "r", encoding="utf-8") as f:
    sample_reqs = list(csv.DictReader(f))
with open("dataset/deletion_requests.csv", "r", encoding="utf-8") as f:
    eval_reqs = list(csv.DictReader(f))
all_reqs = sample_reqs + eval_reqs

with open("dataset/system_activity.csv", "r", encoding="utf-8") as f:
    acts = list(csv.DictReader(f))

# Filter deletion_worker events
dw_acts = [a for a in acts if a["source_system"] == "deletion_worker"]
print(f"Total deletion_worker events: {len(dw_acts)}")

# Group acts by source_system
from collections import Counter
print("By source_system:", Counter(a["source_system"] for a in acts))
print("deletion_worker by target_system:", Counter(a["target_system"] for a in dw_acts))

# Check how deletion_worker account_service events match cases by requested_at <= event_time <= reported_at
del_acc_acts = [a for a in dw_acts if a["target_system"] == "account_service" and a["event_type"] == "DELETE_RECORD"]
print(f"Total deletion_worker DELETE_RECORD account_service: {len(del_acc_acts)}")

matched_cases = 0
for r in all_reqs:
    req_t = r["requested_at"]
    rep_t = r["reported_at"]
    matches = [a for a in del_acc_acts if req_t <= a["event_time"] <= rep_t]
    if len(matches) == 1:
        matched_cases += 1
    else:
        print(f"Case {r['case_id']}: {len(matches)} matches ({req_t} .. {rep_t})")

print(f"Exact 1-to-1 matches by requested_at..reported_at: {matched_cases}")
