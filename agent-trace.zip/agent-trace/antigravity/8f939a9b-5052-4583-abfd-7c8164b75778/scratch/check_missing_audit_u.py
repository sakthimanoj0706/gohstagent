from crack_audit_formula import clean_pairs

missing_u = [u for u in range(11, 551) if "audit_record" not in clean_pairs.get(u, {})]
print(f"Total missing audit_record in u=11..550: {len(missing_u)}")
print("Missing u ranges:", missing_u)
