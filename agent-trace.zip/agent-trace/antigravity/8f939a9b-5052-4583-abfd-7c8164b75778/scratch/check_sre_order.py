import json

with open("dataset/evidence/records/service_resource_export_20260915_114455.json", "r", encoding="utf-8") as f:
    d = json.load(f)

for sys_id, val in d["service_exports"].items():
    print(f"=== {sys_id} ===")
    for r in val["records"]:
        print("  ", r.get("resource_id"), r.get("user_id") or r.get("subject_reference") or r.get("customer_reference") or r.get("email") or r.get("customer_email") or r.get("owner_email") or r.get("requester_email"))
