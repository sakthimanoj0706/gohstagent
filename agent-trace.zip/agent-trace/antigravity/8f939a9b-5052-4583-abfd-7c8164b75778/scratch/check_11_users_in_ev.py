from crack_audit_formula import clean_pairs
import csv, json, os, re

with open("dataset/evidence_files.csv", "r", encoding="utf-8") as f:
    ev_manifest = {r["file_id"]: r for r in csv.DictReader(f)}

# Search all evidence files for user_03, user_07, user_09, user_11, user_13, user_14, user_16, user_17, user_18, user_20, user_22
targets = [3, 7, 9, 11, 13, 14, 16, 17, 18, 20, 22]
for u in targets:
    print(f"=== user_{u:02d}: clean_pairs={clean_pairs.get(u)} ===")
    pat = re.compile(rf"\buser_{u:02d}\b")
    for fid, m in ev_manifest.items():
        fp = os.path.join("dataset", m["file_path"])
        if fp.endswith((".sql", ".json", ".log", ".txt")):
            with open(fp, "r", encoding="utf-8", errors="ignore") as f:
                txt = f.read()
            if pat.search(txt):
                print(f"   Found in {fid} ({m['captured_at']}) -> {m['file_path']}")
