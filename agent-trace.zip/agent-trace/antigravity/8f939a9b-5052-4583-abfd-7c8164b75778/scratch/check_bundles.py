import os
import json
import glob

dataset_dir = r"D:\hacker\dataset"

for p in sorted(glob.glob(os.path.join(dataset_dir, "evidence", "records", "customer_data_snapshot_bundle_*.json"))):
    with open(p, "r", encoding="utf-8") as f:
        data = json.load(f)
    snaps = data.get("snapshots", [])
    caps = sorted(set(s["captured_at"] for s in snaps))
    uids = set()
    for s in snaps:
        for r in s.get("records", []):
            u = r.get("customer_reference") or r.get("subject_reference") or r.get("user_id")
            if u:
                uids.add(u)
    print(f"{os.path.basename(p):45s} | exported={data['exported_at']} | snap_caps={caps} | uids={sorted(uids)[:5]}..{sorted(uids)[-2:] if uids else []}")
