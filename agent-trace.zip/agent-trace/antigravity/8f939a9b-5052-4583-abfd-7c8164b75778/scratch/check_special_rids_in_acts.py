import csv

with open("dataset/system_activity.csv", "r", encoding="utf-8") as f:
    acts = list(csv.DictReader(f))

rids = {
    "account_003", "audit_record_003",
    "account_007", "object_19",
    "account_009", "marketing_001",
    "account_5762", "audit_record_3753",
    "account_8491", "search_428", "audit_record_8925",
    "account_8926", "data_flow_1121", "search_4801", "audit_record_7301",
    "account_9494", "backup_9287", "search_4882", "audit_record_2857",
    "account_4092", "tombstone_17", "backup_3245", "audit_record_1797",
    "account_2373", "export_1842", "export_1260", "search_2352", "audit_record_8486",
    "account_3270", "analytics_7438", "search_4639", "audit_record_5080",
    "support_1034", "search_2912", "audit_record_9644",
}

for a in acts:
    if a["resource_id"] in rids:
        print(f"{a['activity_id']:12s} | {a['event_time']} | {a['source_system']:18s}->{a['target_system']:18s} | {a['event_type']:22s} | {a['resource_id']:18s} | {a['reported_result']:8s}")
