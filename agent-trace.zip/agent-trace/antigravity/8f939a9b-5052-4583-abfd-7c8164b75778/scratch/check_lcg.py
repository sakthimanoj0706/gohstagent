# Let's check differences for known (u, c, sys_id, num)!
import os, csv, json
from collections import defaultdict

dataset_dir = r"D:\hacker\dataset"
with open(os.path.join(dataset_dir, "user_identities.csv"), "r", encoding="utf-8") as f:
    users = {r["user_id"]: r for r in csv.DictReader(f)}
with open(os.path.join(dataset_dir, "user_audit_log.csv"), "r", encoding="utf-8") as f:
    audits = list(csv.DictReader(f))

email_to_uid = {u["email"].lower(): uid for uid, u in users.items()}
for a in audits:
    if a["field_name"] == "email":
        email_to_uid[a["old_value"].lower()] = a["user_id"]
        email_to_uid[a["new_value"].lower()] = a["user_id"]

all_reqs = {}
for fn in ["sample_deletion_requests.csv", "deletion_requests.csv"]:
    with open(os.path.join(dataset_dir, fn), "r", encoding="utf-8") as f:
        for r in csv.DictReader(f):
            all_reqs[r["case_id"]] = r

uid_to_cid = {}
for cid, r in all_reqs.items():
    uid = email_to_uid.get(r["email"].lower())
    if uid:
        uid_to_cid[uid] = cid

known_rids = defaultdict(dict)
with open(os.path.join(dataset_dir, "sample_output.csv"), "r", encoding="utf-8") as f:
    for r in csv.DictReader(f):
        cid = r["case_id"]
        uid = email_to_uid.get(all_reqs[cid]["email"].lower())
        for s in json.loads(r["steps_json"]):
            known_rids[uid][s["system_id"]] = int(s["resource_id"].split("_")[-1])

for root, _, files in os.walk(os.path.join(dataset_dir, "evidence")):
    for fn in files:
        if fn.startswith("customer_data_snapshot_bundle_") and fn.endswith(".json"):
            with open(os.path.join(root, fn), "r", encoding="utf-8") as f:
                data = json.load(f)
            for snap in data.get("snapshots", []):
                ds = snap["data_store"]
                for rec in snap.get("records", []):
                    rid = rec.get("resource_id")
                    uid = rec.get("customer_reference") or rec.get("subject_reference") or rec.get("user_id")
                    if not uid:
                        em = rec.get("email") or rec.get("owner_email") or (rec.get("document", {}) or {}).get("email")
                        if em:
                            uid = email_to_uid.get(em.lower())
                    if uid and rid:
                        known_rids[uid][ds] = int(rid.split("_")[-1])

for sys_id in ["account_service", "security_service", "analytics_platform", "search_service", "support_platform", "integration_service", "backup_service", "export_service", "identity_service"]:
    print(f"\n=== {sys_id} ===")
    pts = []
    for uid, m in known_rids.items():
        if uid and "_" in uid and sys_id in m:
            u = int(uid.split("_")[1])
            cid = uid_to_cid.get(uid, "case_0")
            c = int(cid.split("_")[1])
            pts.append((u, c, m[sys_id]))
    pts.sort()
    for u, c, val in pts[:25]:
        print(f"  u={u:3d}, c={c:3d} -> {val:4d}")
