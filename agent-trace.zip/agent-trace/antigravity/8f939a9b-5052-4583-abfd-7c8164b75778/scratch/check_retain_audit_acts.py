import csv
from datetime import datetime
from crack_audit_formula import clean_pairs

with open("dataset/system_activity.csv", "r", encoding="utf-8") as f:
    acts = list(csv.DictReader(f))

ret_acts = [a for a in acts if a["event_type"] == "RETAIN_RECORD" and a["source_system"] == "security_service"]
print(f"Total RETAIN_RECORD security_service rows in system_activity.csv: {len(ret_acts)}")

aud_to_u = {}
for u, d in clean_pairs.items():
    if "audit_record" in d:
        num = d["audit_record"]
        rid = f"audit_record_{num:03d}" if num < 1000 else f"audit_record_{num}"
        aud_to_u[rid] = u

matched = 0
unmatched = []
for a in ret_acts:
    rid = a["resource_id"]
    if rid in aud_to_u:
        matched += 1
    else:
        unmatched.append(a)

print(f"Matched to clean_pairs: {matched}, Unmatched: {len(unmatched)}")
for a in ret_acts[:25]:
    rid = a["resource_id"]
    print(f"  {a['activity_id']:12s} | {a['event_time']} | {rid:18s} | known_u={aud_to_u.get(rid)}")
