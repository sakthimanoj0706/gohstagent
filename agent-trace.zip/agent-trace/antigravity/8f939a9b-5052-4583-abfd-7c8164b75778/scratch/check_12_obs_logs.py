import re, csv

with open("dataset/evidence_files.csv", "r", encoding="utf-8") as f:
    evs = [r for r in csv.DictReader(f) if r["origin"] == "central_observability_export"]

for r in evs:
    with open("dataset/" + r["file_path"], "r", encoding="utf-8") as f:
        txt = f.read()
    auds = sorted(set(re.findall(r"audit_record_\d+", txt)))
    users = sorted(set(re.findall(r"user_\d+", txt)))
    print(f"{r['file_id']:12s} | auds={len(auds):2d} | users={users} | {r['file_path']}")
