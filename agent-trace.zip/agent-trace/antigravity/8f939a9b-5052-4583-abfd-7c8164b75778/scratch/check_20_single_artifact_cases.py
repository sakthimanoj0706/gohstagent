import csv, json

with open("dataset/sample_output.csv", "r", encoding="utf-8") as f:
    sout = {r["case_id"]: r for r in csv.DictReader(f)}

for cid in ["case_01", "case_02", "case_04", "case_05", "case_06", "case_07", "case_08", "case_10"]:
    print(f"=== {cid}: status={sout[cid]['deletion_status']} ===")
    for s in json.loads(sout[cid]["steps_json"]):
        print("  ", s)

with open("dataset/system_activity.csv", "r", encoding="utf-8") as f:
    acts = list(csv.DictReader(f))

print("\n=== Activities for 031, 034, 035, 039, 045, 046, 050, 052, 053, 055, 061, 009 ===")
targets = {"031", "034", "035", "039", "045", "046", "050", "052", "053", "055", "061", "009", "001", "002", "003", "004", "005", "006", "007", "008", "010"}
for a in acts:
    rid = a["resource_id"]
    suf = rid.split("_")[-1]
    if suf in targets and len(suf) == 3:
        print(f"  {a['activity_id']:12s} | {a['event_time']} | {a['source_system']:18s}->{a['target_system']:18s} | {a['event_type']:18s} | {rid:18s} | {a['reported_result']}")
