import os
import csv
import json

dataset_dir = r"D:\hacker\dataset"

with open(os.path.join(dataset_dir, "sample_deletion_requests.csv"), "r", encoding="utf-8") as f:
    s_reqs = {r["case_id"]: r for r in csv.DictReader(f)}
with open(os.path.join(dataset_dir, "deletion_requests.csv"), "r", encoding="utf-8") as f:
    e_reqs = {r["case_id"]: r for r in csv.DictReader(f)}

for cid in ["case_17", "case_46", "case_07", "case_61", "case_33", "case_52"]:
    r = s_reqs.get(cid) or e_reqs.get(cid)
    print(cid, r)

# Also check where account_6523 and account_4092 appear!
with open(os.path.join(dataset_dir, "system_activity.csv"), "r", encoding="utf-8") as f:
    for r in csv.DictReader(f):
        if r["resource_id"] in ("account_4092", "account_6523"):
            print("system_activity:", r)
