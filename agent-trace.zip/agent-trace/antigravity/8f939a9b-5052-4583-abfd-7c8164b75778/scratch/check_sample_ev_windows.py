import csv, json

with open("dataset/sample_deletion_requests.csv", "r", encoding="utf-8") as f:
    sreqs = {r["case_id"]: r for r in csv.DictReader(f)}
with open("dataset/sample_output.csv", "r", encoding="utf-8") as f:
    sout = list(csv.DictReader(f))
with open("dataset/evidence_files.csv", "r", encoding="utf-8") as f:
    ev_manifest = {r["file_id"]: r for r in csv.DictReader(f)}

for row in sout:
    cid = row["case_id"]
    req = sreqs[cid]
    steps = json.loads(row["steps_json"])
    eids = sorted(set(s["evidence_id"] for s in steps if s["evidence_id"]))
    for eid in eids:
        cap = ev_manifest[eid]["captured_at"]
        print(f"{cid:8s} | {eid:12s} | req={req['requested_at']} <= cap={cap} <= aud={req['audit_at']} : {req['requested_at'] <= cap <= req['audit_at']}")
