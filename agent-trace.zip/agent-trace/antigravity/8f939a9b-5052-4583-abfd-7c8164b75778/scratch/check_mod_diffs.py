from crack_audit_formula import clean_pairs

aud = {u: clean_pairs[u]["audit_record"] for u in clean_pairs if u > 10 and "audit_record" in clean_pairs[u]}

for u in range(12, 91):
    if u in aud and (u-1) in aud:
        d = aud[u] - aud[u-1]
        d10000 = d % 10000
        d9999 = d % 9999
        d9000 = d % 9000
        print(f"u={u-1:2d}->{u:2d}: {aud[u-1]:4d} -> {aud[u]:4d} | d={d:5d} | %10000={d10000:4d} | %9999={d9999:4d}")
