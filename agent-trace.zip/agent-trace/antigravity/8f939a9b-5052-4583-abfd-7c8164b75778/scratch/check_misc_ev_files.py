import json, re

for fid, fp in [
    ("evidence_08", "dataset/evidence/logs/search_index_diagnostic_20260906.log"),
    ("evidence_13", "dataset/evidence/records/connector_configurations_20260812.json"),
    ("evidence_36", "dataset/evidence/records/customer_export_manifest_20260409.json"),
    ("evidence_41", "dataset/evidence/logs/notification_delivery_20260315.log"),
    ("evidence_50", "dataset/evidence/records/security_audit_ledger_20261001.json"),
]:
    with open(fp, "r", encoding="utf-8") as f:
        txt = f.read()
    users = sorted(set(re.findall(r"user_\d+", txt)))
    rids = sorted(set(re.findall(r"(?:account|search|support|analytics|export|data_flow|backup|audit_record|tombstone|legal_hold|email_delivery|cache)_\d+", txt)))
    print(f"{fid}: users={users[:10]} (total {len(users)}), rids={rids[:10]} (total {len(rids)})")
