import csv, json
from datetime import datetime

with open("dataset/user_identities.csv", "r", encoding="utf-8") as f:
    email_to_u = {r["email"]: int(r["user_id"].split("_")[1]) for r in csv.DictReader(f)}
with open("dataset/user_audit_log.csv", "r", encoding="utf-8") as f:
    for r in csv.DictReader(f):
        if r["field_name"] == "email":
            email_to_u[r["old_value"]] = int(r["user_id"].split("_")[1])
            email_to_u[r["new_value"]] = int(r["user_id"].split("_")[1])

with open("dataset/sample_deletion_requests.csv", "r", encoding="utf-8") as f:
    sample_reqs = list(csv.DictReader(f))
with open("dataset/sample_output.csv", "r", encoding="utf-8") as f:
    sample_out = {r["case_id"]: json.loads(r["steps_json"]) for r in csv.DictReader(f)}
with open("dataset/system_activity.csv", "r", encoding="utf-8") as f:
    acts = list(csv.DictReader(f))

by_res = {}
for a in acts:
    by_res.setdefault(a["resource_id"], []).append(a)

def parse_t(s):
    return datetime.fromisoformat(s.replace("Z", "+00:00"))

rows = []
for r in sample_reqs:
    cid = r["case_id"]
    cnum = int(cid.split("_")[1])
    unum = email_to_u[r["email"]]
    rep_t = parse_t(r["reported_at"])
    for s in sample_out[cid]:
        rid = s["resource_id"]
        for a in by_res.get(rid, []):
            if a["event_type"] == "DELETE_RECORD" and a["target_system"] == "account_service":
                ev_t = parse_t(a["event_time"])
                rows.append((unum, cnum, int((ev_t - rep_t).total_seconds()), rid))
                break

for unum, cnum, diff, rid in sorted(rows):
    print(f"u={unum:3d} | c={cnum:3d} | diff={diff:6d}s ({-diff//60:2d}m {-diff%60:02d}s) | {rid}")
