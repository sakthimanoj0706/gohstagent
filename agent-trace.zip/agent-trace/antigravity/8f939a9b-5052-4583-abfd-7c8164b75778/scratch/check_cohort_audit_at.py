import os
import csv
from collections import defaultdict

dataset_dir = r"D:\hacker\dataset"

with open(os.path.join(dataset_dir, "user_identities.csv"), "r", encoding="utf-8") as f:
    users = {r["user_id"]: r for r in csv.DictReader(f)}
with open(os.path.join(dataset_dir, "user_audit_log.csv"), "r", encoding="utf-8") as f:
    audits = list(csv.DictReader(f))

email_to_uid = {u["email"].lower(): uid for uid, u in users.items()}
for a in audits:
    if a["field_name"] == "email":
        email_to_uid[a["old_value"].lower()] = a["user_id"]
        email_to_uid[a["new_value"].lower()] = a["user_id"]

with open(os.path.join(dataset_dir, "sample_deletion_requests.csv"), "r", encoding="utf-8") as f:
    s_reqs = list(csv.DictReader(f))
with open(os.path.join(dataset_dir, "deletion_requests.csv"), "r", encoding="utf-8") as f:
    e_reqs = list(csv.DictReader(f))

uid_to_req = {}
for r in s_reqs + e_reqs:
    uid = email_to_uid[r["email"].lower()]
    uid_to_req[uid] = r

for c_start in range(1, 551, 10):
    audit_ats = set()
    for u in range(c_start, c_start + 10):
        uid = f"user_{u:02d}" if u < 100 else f"user_{u}"
        if uid in uid_to_req:
            audit_ats.add(uid_to_req[uid]["audit_at"])
    print(f"Cohort {c_start:3d}..{c_start+9:3d}: audit_at = {sorted(audit_ats)}")
