import os, json, csv

with open("dataset/user_identities.csv", "r", encoding="utf-8") as f:
    identities = {r["user_id"]: r for r in csv.DictReader(f)}
with open("dataset/user_audit_log.csv", "r", encoding="utf-8") as f:
    audits = list(csv.DictReader(f))

print("Total audit rows:", len(audits))
for a in audits[:30]:
    print(" ", a)
