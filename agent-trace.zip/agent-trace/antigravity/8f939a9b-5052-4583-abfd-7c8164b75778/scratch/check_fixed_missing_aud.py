from crack_audit_formula import clean_pairs
import os, json, re

# Add lookup_value from customer_data_snapshot_bundle_*.json
with open("dataset/user_identities.csv", "r", encoding="utf-8") as f:
    import csv
    users = {r["user_id"]: r for r in csv.DictReader(f)}

rec_dir = "dataset/evidence/records"
for fn in sorted(os.listdir(rec_dir)):
    if not fn.endswith(".json"): continue
    with open(os.path.join(rec_dir, fn), "r", encoding="utf-8") as f:
        data = json.load(f)
    def walk(obj):
        if isinstance(obj, dict):
            rid = obj.get("resource_id", "")
            uid = obj.get("lookup_value") or obj.get("subject_reference") or obj.get("user_id")
            if isinstance(uid, str) and uid.startswith("user_") and isinstance(rid, str) and "_" in rid:
                u = int(uid.split("_")[1])
                pref, num = rid.rsplit("_", 1)
                if num.isdigit():
                    clean_pairs[u][pref] = int(num)
            for v in obj.values():
                walk(v)
        elif isinstance(obj, list):
            for x in obj:
                walk(x)
    walk(data)

missing = [u for u in range(11, 551) if u not in (31, 44, 59) and not (531 <= u <= 540) and "audit_record" not in clean_pairs[u]]
print(f"Total missing audit_record after lookup_value fix: {len(missing)}")
print("Missing:", missing)
