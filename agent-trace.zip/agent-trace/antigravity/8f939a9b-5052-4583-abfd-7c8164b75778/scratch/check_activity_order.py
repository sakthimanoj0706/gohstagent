import csv

with open("dataset/system_activity.csv", "r", encoding="utf-8") as f:
    acts = list(csv.DictReader(f))

for i in range(45):
    a = acts[i]
    print(f"{a['activity_id']:12s} | {a['event_time']} | {a['event_type']:18s} | {a['source_system']:18s} -> {a['target_system']:18s} | {a['resource_id']:18s} | {a['reported_result']:12s} | {a['details']}")
